R package with some useful functions and r markdown templates.

Install by running
```
install.packages("devtools")
devtools::install_github("kemacdonald/kmr")
```